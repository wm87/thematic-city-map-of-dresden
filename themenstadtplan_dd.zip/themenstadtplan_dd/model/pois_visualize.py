from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterNumber
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterString
from qgis.core import QgsProcessingParameterFeatureSink
import processing


class AnzahlSchulen(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterNumber('anzahlschulen', 'Anzahl POIs', type=QgsProcessingParameterNumber.Integer, minValue=1, maxValue=10, defaultValue=1))
        self.addParameter(QgsProcessingParameterVectorLayer('pois', 'POIs', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterString('poisfiltern', 'POIs filtern', multiLine=False, defaultValue='school'))
        self.addParameter(QgsProcessingParameterVectorLayer('stadtteile2', 'Stadtteile', types=[QgsProcessing.TypeVectorPolygon], defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Ergebnis', 'Ergebnis', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(4, model_feedback)
        results = {}
        outputs = {}

        # POI extrahieren
        alg_params = {
            'FIELD': 'fclass',
            'INPUT': parameters['pois'],
            'OPERATOR': 0,
            'VALUE': parameters['poisfiltern'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PoiExtrahieren'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Attribute nach Position verknüpfen (Zusammenfassung)
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'INPUT': parameters['stadtteile2'],
            'JOIN': outputs['PoiExtrahieren']['OUTPUT'],
            'JOIN_FIELDS': 'fclass',
            'PREDICATE': 1,
            'SUMMARIES': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AttributeNachPositionVerknpfenZusammenfassung'] = processing.run('qgis:joinbylocationsummary', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Anzahl POIs extrahieren
        alg_params = {
            'FIELD': 'fclass_count',
            'INPUT': outputs['AttributeNachPositionVerknpfenZusammenfassung']['OUTPUT'],
            'OPERATOR': 3,
            'VALUE': parameters['anzahlschulen'],
            'FAIL_OUTPUT': QgsProcessing.TEMPORARY_OUTPUT,
            'OUTPUT': parameters['Ergebnis']
        }
        outputs['AnzahlPoisExtrahieren'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Ergebnis'] = outputs['AnzahlPoisExtrahieren']['OUTPUT']

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Setze Stil für Vektorlayer
        alg_params = {
            'INPUT': outputs['AnzahlPoisExtrahieren']['FAIL_OUTPUT'],
            'STYLE': 'C:\\Dateiablage_Austausch_19\\Themenstadtplan\\qml\\anz_schulen_pro_stadtteil.qml'
        }
        outputs['SetzeStilFrVektorlayer'] = processing.run('qgis:setstyleforvectorlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        return results

    def name(self):
        return 'Anzahl Schulen'

    def displayName(self):
        return 'Anzahl Schulen'

    def group(self):
        return 'Eigene Modelle'

    def groupId(self):
        return 'Eigene Modelle'

    def createInstance(self):
        return AnzahlSchulen()
